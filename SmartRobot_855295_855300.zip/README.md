# Smart Robot
*Dmytro Bohdiev 855295*

*Bohdan Karabadzhak 855300*

## Short project description (Business needs and system features)
The system that is recognizing visual gestures and controls with them the robot. The hardware implementation is based on ESP32 and a laptop, equipped with sensors.

## System Architecture
### Robot Part
#### The robot is based on next parts: 
- ROBOT-2WDL-KIT from olimex
- ESP32-DevKit-LiPo         
- BB-TB6612 - dual DC motor driver
- KIT K2079 - encoders

The Robot is programmed on espressif / arduino-esp32 framework and represents a wi-fi access point and UDP Server that is accepting UDP packets. The Robot is controlled by commands from UDP packets that have to contain an ID of an action. 

#### Module structure:
```
Smart Robot
└── src
    └── main.cpp
```
The `main.cpp` file contains all the needed code and configurational constants. 

#### Code is based on next libraries:
- `<Arduino.h>`
- `<WiFi.h>`
- `<WiFiUdp.h>`
- `"esp32-hal-ledc.h"`

### Laptop Part
The laptop part is represented as a UDP Client programmed in python language.

#### Code is based on next libraries: 
- OpenCV
- MediaPipe
- NumPy
- TensorFlow

#### Module structure:
```
hand-gesture-recognition-mediapipe
├── LICENSE
├── README.md
├── app.py
├── keypoint_classification.ipynb
├── keypoint_classification_EN.ipynb
├── model
│   ├── __init__.py
│   ├── __pycache__
│   │   ├── __init__.cpython-310.pyc
│   │   └── __init__.cpython-39.pyc
│   ├── keypoint_classifier
│   │   ├── __pycache__
│   │   │   ├── keypoint_classifier.cpython-310.pyc
│   │   │   └── keypoint_classifier.cpython-39.pyc
│   │   ├── keypoint.csv
│   │   ├── keypoint_classifier.hdf5
│   │   ├── keypoint_classifier.py
│   │   ├── keypoint_classifier.tflite
│   │   └── keypoint_classifier_label.csv
│   └── point_history_classifier
```

The `app.py` file contains the main code is recognizing the hand and gesture and sends the packet with a gesture id to esp32. 
The `keypoint_classification.ipynb` is a jupyter notebook with scripts for model training.
The `keypoint.csv` is a points collection for each gesture. This file is used for model training.
The `keypoint_classifier_label.csv` is a labels collection for each gesture. The first column of `keypoint.csv` is a gesture id and an each line number of `keypoint_classifier_label.csv` meets same gesture id.

## Steps to setup
1. Run app.py
2. Push K button
3. Form your hand gesture on camera
4. Do allot of snapshots of your hand by typing a number
5. Run jupyter notebook 
6. Open keypoint_classification.ipynb 
7. Run All Cells
8. app.py have to recognize your gesture
9. Turn on esp32 
10. Connect to configured on esp32 wi-fi

## Links and Resources
- [Arduino framework documentation](https://docs.espressif.com/projects/arduino-esp32/en/latest/libraries.html "Arduino framework documentation")
- [Mediapipe library with hand detection library](https://google.github.io/mediapipe/ "Mediapipe library with hand detection library")
- [Guide for Japanise code](https://www.youtube.com/watch?v=a99p_fAr6e4 "Guide for Japanise code")